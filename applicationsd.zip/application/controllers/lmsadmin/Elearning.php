<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Auth
 * @property Ion_auth|Ion_auth_model $ion_auth        The ION Auth spark
 * @property CI_Form_validation      $form_validation The form validation library
 */
class Elearning extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
		$this->load->library(array('ion_auth', 'form_validation'));
		$this->load->helper(array('url', 'language'));
		$this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));
		$this->lang->load('auth');
		$this->load->model("Classroom_model");
	}

	 /* View Course
	 * @ GET all List
	 * @ prama Post 
	*/
	public function courses(){
		
		/*check login by role after login*/
		if (!$this->ion_auth->logged_in())
		{
			// redirect them to the login page
			redirect('auth/login', 'refresh');
		}
		else if (!$this->ion_auth->is_admin()) // remove this elseif if you want to enable this for non-admins
		{
			// redirect them to the home page because they must be an administrator to view this
			return show_error('You must be an administrator to view this page.');
		}
		else if(!$this->ion_auth->is_modules('LMS')){
			// Showing error  because they must be LMS  to view this
			return show_error('You must be an administrator to view this page LMS.');
		}else{
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');
			$this->data['title'] = $this->lang->line('course_management');
			
			$courslist = $this->Common_model->select_info("lms_courses");
			$this->data['courses'] = $courslist;
			$this->_render_page('lms_admin/courses/index', $this->data);
		}
		 
	}
	
	/**
	 * Create a new Course
	 */
	public function addcourses()
	{
		$userId = $this->ion_auth->get_user_id();
		if (!$this->ion_auth->logged_in())
		{
			// redirect them to the login page
			redirect('auth/login', 'refresh');
		}
		else if (!$this->ion_auth->is_admin()) // remove this elseif if you want to enable this for non-admins
		{
			// redirect them to the home page because they must be an administrator to view this
			return show_error('You must be an administrator to view this page.');
		}
		else if(!$this->ion_auth->is_modules('LMS')){
			// Showing error  because they must be LMS  to view this
			return show_error('You must be an administrator to view this page LMS.');
		}else{			
			$this->data['title'] = $this->lang->line('create_course_heading');
			
			if (isset($_POST) && !empty($_POST))
			{
				// do we have a valid request?
				if ($this->_valid_csrf_nonce() === FALSE)
				{
					show_error($this->lang->line('error_csrf'));
				}
			
				// validate form input
				$this->form_validation->set_rules('course_name', str_replace(':', '', $this->lang->line('index_coursename_th')), 'required');
				$this->form_validation->set_rules('compliance_standard', str_replace(':', '', $this->lang->line('index_com_stand_th')), 'required');
				$this->form_validation->set_rules('status', str_replace(':', '', $this->lang->line('index_com_stand_th')), 'required');
			
				if ($this->form_validation->run() === TRUE)
				{
					$data_arr = array(
						'name' =>$this->input->post('course_name'),
						'reference_title' => $this->input->post('ref_title'),
						'objectives' =>$this->input->post('learning_objectives'),
						'seat_time' =>$this->input->post('seat_time'),
						'description'=>$this->input->post('about_course'),
						'status_id'=>$this->input->post('status'),
						'cpd_points'=>$this->input->post('cpd_points'),
						'created_at'=>date('y-m-d'),
						'created_by'=>$userId,
											
					);				
					$data_arr = $this->security->xss_clean($data_arr);
					$insert_id = $this->Common_model->insert_info('lms_courses',$data_arr);
					if($insert_id){
						$this->session->set_flashdata('message', "Course added successfully.");						
						redirect('lmsadmin/elearning/courses', 'refresh');
					}	
					
					
				}
			}
				$this->data['csrf'] = $this->_get_csrf_nonce();
				$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');
				$this->data['course_name'] = array('name' => 'course_name',
					'id' => 'course_name',
					'class'=>'md-input',
					'type' => 'text',
					'value' => $this->form_validation->set_value('course_name'),
				);
				
				$this->data['ref_title'] = array('name' => 'ref_title',
					'id' => 'ref_title',
					'class'=>'md-input',
					'type' => 'text',
					'value' => set_value('ref_title'),
				);
				$this->data['learning_objectives'] = array('name' => 'learning_objectives',
					'id' => 'learning_objectives',
					'class'=>'md-input',
					'value' => set_value('learning_objectives'),
				);
				
				$compliance_arr = array('1'=> 'AICC', '2'=> 'SCORM 1.2','3'=>'SCORM 2004','4'=>'Tin Can','5'=>'Proprietary');
				$this->data['compliance_standard'] = array(
					'name' => 'compliance_standard',
					'id' => 'compliance_standard',
					'options' => 	$compliance_arr,
					'data-md-selectize'=>'',
					'selected' => set_value('compliance_standard'),
				);
				
				$this->data['seat_time'] = array('name' => 'seat_time',
					'id' => 'kUI_timepicker',
					'class'=>'uk-form-width-medium',
					'type' => 'number',
					'value' => set_value('seat_time'),
				);
				
				
				$this->data['about_course'] = array('name' => 'about_course',
					'id' => 'about_course',
					'class'=>'md-input',
					'value' => set_value('about_course'),
				);
				
				$this->data['cpd_points'] = array('name' => 'cpd_points',
					'id' => 'cpd_points',
					'class'=>'md-input',
					'type' => 'text',
					'value' => set_value('cpd_points'),
				);
				
				$status = array(
						'1'         => 'Active',
						'2'           => 'In Active'						
					);
				$this->data['status'] = array(
					'name' => 'status',
					'id' => 'status',
					'options' => 	$status,
					'data-md-selectize'=>'',
					'selected' => set_value('status'),
				);
				$this->_render_page('lms_admin/courses/add', $this->data);
		}
		
		
	}
	
	
	/**
	 * Update user
	 */
	
	 public function updatecourse($id){
		if(!$this->Common_model->is_exits('lms_courses','lms_course_id',array('lms_course_id'=>$id))){
			$this->session->set_flashdata('message', "Somthing error!, Please try again");		
			redirect('lmsadmin/elearning/courses', 'refresh');
		}
		
		$this->data['title'] = $this->lang->line('edit_user_heading');
		$userId = $this->ion_auth->get_user_id();
		if (!$this->ion_auth->logged_in())
		{
			// redirect them to the login page
			redirect('auth/login', 'refresh');
		}
		else if (!$this->ion_auth->is_admin()) // remove this elseif if you want to enable this for non-admins
		{
			// redirect them to the home page because they must be an administrator to view this
			return show_error('You must be an administrator to view this page.');
		}
		else if(!$this->ion_auth->is_modules('LMS')){
			// Showing error  because they must be LMS  to view this
			return show_error('You must be an administrator to view this page LMS.');
		}else{
			$courslist = $this->Common_model->select_info("lms_courses",array('lms_course_id'=>$id));
			$courslist = $courslist[0];
			
			// validate form input
			$this->form_validation->set_rules('course_name', str_replace(':', '', $this->lang->line('index_coursename_th')), 'required');
			$this->form_validation->set_rules('compliance_standard', str_replace(':', '', $this->lang->line('index_com_stand_th')), 'required');
			$this->form_validation->set_rules('status', str_replace(':', '', $this->lang->line('index_com_stand_th')), 'required');
			if (isset($_POST) && !empty($_POST))
			{
				// do we have a valid request?
				if ($this->_valid_csrf_nonce() === FALSE || $id != $this->input->post('id'))
				{
					show_error($this->lang->line('error_csrf'));
				}
				if ($this->form_validation->run() === TRUE){
					$data_arr = array(
						'name' =>$this->input->post('course_name'),
						'reference_title' => $this->input->post('ref_title'),
						'objectives' =>$this->input->post('learning_objectives'),
						'seat_time' =>$this->input->post('seat_time'),
						'description'=>$this->input->post('about_course'),
						'status_id'=>$this->input->post('status'),
						'cpd_points'=>$this->input->post('cpd_points'),
						'created_at'=>date('y-m-d'),
						'created_by'=>$userId,
											
					);				
					$data_arr = $this->security->xss_clean($data_arr);
					$insert_id = $this->Common_model->update_info('lms_courses',$data_arr,array('lms_course_id'=>$id));
					if($insert_id){
						$this->session->set_flashdata('message', "Course updated successfully.");						
						redirect('lmsadmin/elearning/courses', 'refresh');
					}	
				}
			}
				$this->data['csrf'] = $this->_get_csrf_nonce();
				$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');
				$this->data['course_name'] = array('name' => 'course_name',
					'id' => 'course_name',
					'class'=>'md-input',
					'type' => 'text',
					'value' => $this->form_validation->set_value('course_name',$courslist['name']),
				);
				
				$this->data['ref_title'] = array('name' => 'ref_title',
					'id' => 'ref_title',
					'class'=>'md-input',
					'type' => 'text',
					'value' => set_value('ref_title',$courslist['reference_title']),
				);
				$this->data['learning_objectives'] = array('name' => 'learning_objectives',
					'id' => 'learning_objectives',
					'class'=>'md-input',
					'value' => set_value('learning_objectives',$courslist['objectives']),
				);
				
				$compliance_arr = array('1'=> 'AICC', '2'=> 'SCORM 1.2','3'=>'SCORM 2004','4'=>'Tin Can','5'=>'Proprietary');
				$this->data['compliance_standard'] = array(
					'name' => 'compliance_standard',
					'id' => 'compliance_standard',
					'options' => 	$compliance_arr,
					'data-md-selectize'=>'',
					'selected' => set_value('compliance_standard'),
				);
				
				$this->data['seat_time'] = array('name' => 'seat_time',
					'id' => 'kUI_timepicker',
					'class'=>'uk-form-width-medium',
					'type' => 'number',
					'value' => set_value('seat_time',$courslist['seat_time']),
				);
				
				
				$this->data['about_course'] = array('name' => 'about_course',
					'id' => 'about_course',
					'class'=>'md-input',
					'value' => set_value('about_course',$courslist['description']),
				);
				
				$this->data['cpd_points'] = array('name' => 'cpd_points',
					'id' => 'cpd_points',
					'class'=>'md-input',
					'type' => 'text',
					'value' => set_value('cpd_points',$courslist['cpd_points']),
				);
				
				$status = array(
						'1'         => 'Active',
						'2'           => 'In Active'						
					);
				$this->data['status'] = array(
					'name' => 'status',
					'id' => 'status',
					'options' => 	$status,
					'data-md-selectize'=>'',
					'selected' => set_value('status',$courslist['status_id']),
				);
				$this->data['lms_course_id'] = $courslist['lms_course_id'];
				$this->_render_page('lms_admin/courses/edit', $this->data);
		}
		
	 }
	
	
	 /* View Videos
	 * @ GET all List
	 * @ prama Post 
	*/
	public function videos(){
		
		/*check login by role after login*/
		if (!$this->ion_auth->logged_in())
		{
			// redirect them to the login page
			redirect('auth/login', 'refresh');
		}
		else if (!$this->ion_auth->is_admin()) // remove this elseif if you want to enable this for non-admins
		{
			// redirect them to the home page because they must be an administrator to view this
			return show_error('You must be an administrator to view this page.');
		}
		else if(!$this->ion_auth->is_modules('LMS')){
			// Showing error  because they must be LMS  to view this
			return show_error('You must be an administrator to view this page LMS.');
		}else{
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');
			$this->data['title'] = $this->lang->line('video_management');
			
			$videos = $this->Common_model->select_info("lms_videos");
			$this->data['videos'] = $videos;
			$this->_render_page('lms_admin/videos/index', $this->data);
		}
		 
	}

	/*
		build session course
	*/
	
	public function build_session_course($url){
		
		/*check login by role after login*/
		if (!$this->ion_auth->logged_in())
		{
			// redirect them to the login page
			redirect('auth/login', 'refresh');
		}
		else if (!$this->ion_auth->is_admin()) // remove this elseif if you want to enable this for non-admins
		{
			// redirect them to the home page because they must be an administrator to view this
			return show_error('You must be an administrator to view this page.');
		}
		else if(!$this->ion_auth->is_modules('LMS')){
			// Showing error  because they must be LMS  to view this
			return show_error('You must be an administrator to view this page LMS.');
		}else{
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

			$this->data['title'] = $this->lang->line('build_session_course');

			
			

			$this->data['url']=$url;
			//course table data
			$courses=$this->Classroom_model->buildcourse($url);
			$this->data['courses'] = $courses;
			$this->_render_page('lms_admin/training/add_courses', $this->data);
		}
		 
	}

	/*
		build session video
	*/
	
	public function build_session_video($url){
		
		/*check login by role after login*/
		if (!$this->ion_auth->logged_in())
		{
			// redirect them to the login page
			redirect('auth/login', 'refresh');
		}
		else if (!$this->ion_auth->is_admin()) // remove this elseif if you want to enable this for non-admins
		{
			// redirect them to the home page because they must be an administrator to view this
			return show_error('You must be an administrator to view this page.');
		}
		else if(!$this->ion_auth->is_modules('LMS')){
			// Showing error  because they must be LMS  to view this
			return show_error('You must be an administrator to view this page LMS.');
		}else{
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

			$this->data['url']=$url;

			$this->data['title'] = $this->lang->line('build_session_video');
			//video table data
			$videos=$this->Classroom_model->buildvideo($url);
			$this->data['videos'] = $videos;
			$this->_render_page('lms_admin/training/add_video', $this->data);
		}
		 
	}

	/*
		build session course
	*/
	
	public function build_session_session($url){
		
		/*check login by role after login*/
		if (!$this->ion_auth->logged_in())
		{
			// redirect them to the login page
			redirect('auth/login', 'refresh');
		}
		else if (!$this->ion_auth->is_admin()) // remove this elseif if you want to enable this for non-admins
		{
			// redirect them to the home page because they must be an administrator to view this
			return show_error('You must be an administrator to view this page.');
		}
		else if(!$this->ion_auth->is_modules('LMS')){
			// Showing error  because they must be LMS  to view this
			return show_error('You must be an administrator to view this page LMS.');
		}else{
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');


			$this->data['url']=$url;

			$this->data['title'] = $this->lang->line('build_session_session');
			
			//session data table
			$sessions=$this->Classroom_model->buildsession($url);
			$this->data['sessions'] = $sessions;
			$this->_render_page('lms_admin/training/add_session', $this->data);
		}
		 
	}

	/*
		build session assignment
	*/
	
	public function build_session_assignment($url){
		
		/*check login by role after login*/
		if (!$this->ion_auth->logged_in())
		{
			// redirect them to the login page
			redirect('auth/login', 'refresh');
		}
		else if (!$this->ion_auth->is_admin()) // remove this elseif if you want to enable this for non-admins
		{
			// redirect them to the home page because they must be an administrator to view this
			return show_error('You must be an administrator to view this page.');
		}
		else if(!$this->ion_auth->is_modules('LMS')){
			// Showing error  because they must be LMS  to view this
			return show_error('You must be an administrator to view this page LMS.');
		}else{
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

			$this->data['url']=$url;
			
			$this->data['title'] = $this->lang->line('build_session_assignment');
			
			//assignment table data
			$assignments=$this->Classroom_model->buildassignment($url);
			$this->data['assignments'] = $assignments;
			$this->_render_page('lms_admin/training/add_assignment', $this->data);
		}
		 
	}

	public function build_session_feedback($url){
		
		/*check login by role after login*/
		if (!$this->ion_auth->logged_in())
		{
			// redirect them to the login page
			redirect('auth/login', 'refresh');
		}
		else if (!$this->ion_auth->is_admin()) // remove this elseif if you want to enable this for non-admins
		{
			// redirect them to the home page because they must be an administrator to view this
			return show_error('You must be an administrator to view this page.');
		}
		else if(!$this->ion_auth->is_modules('LMS')){
			// Showing error  because they must be LMS  to view this
			return show_error('You must be an administrator to view this page LMS.');
		}else{
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

			$this->data['url']=$url;
			
			$this->data['title'] = $this->lang->line('build_session_feedback');
			
			//video table data
			$feedback=$this->Classroom_model->buildfeedback($url);
			$this->data['feedback'] = $feedback;
			$this->_render_page('lms_admin/training/add_feedback', $this->data);
		}
		 
	}

	public function add_course_to_training_assign($training_id,$course_id){
		/*check login by role after login*/
		if (!$this->ion_auth->logged_in())
		{
			// redirect them to the login page
			redirect('auth/login', 'refresh');
		}
		else if (!$this->ion_auth->is_admin()) // remove this elseif if you want to enable this for non-admins
		{
			// redirect them to the home page because they must be an administrator to view this
			return show_error('You must be an administrator to view this page.');
		}
		else if(!$this->ion_auth->is_modules('LMS')){
			// Showing error  because they must be LMS  to view this
			return show_error('You must be an administrator to view this page LMS.');
		}else{
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

			$courslist = $this->Common_model->insert_info("ims_training_assign",array('lms_training_id'=>$training_id,'lms_course_id'=>$course_id));
			$this->data['title'] = $this->lang->line('build_session_course');

			$this->data['url']=$training_id;
			//course table data
			$courses=$this->Classroom_model->buildcourse($training_id);
			$this->data['courses']=$courses;
			$this->_render_page('lms_admin/training/add_courses', $this->data);
		}
	}

	public function add_sessions_to_training_assign($training_id,$session_id){
		/*check login by role after login*/
		if (!$this->ion_auth->logged_in())
		{
			// redirect them to the login page
			redirect('auth/login', 'refresh');
		}
		else if (!$this->ion_auth->is_admin()) // remove this elseif if you want to enable this for non-admins
		{
			// redirect them to the home page because they must be an administrator to view this
			return show_error('You must be an administrator to view this page.');
		}
		else if(!$this->ion_auth->is_modules('LMS')){
			// Showing error  because they must be LMS  to view this
			return show_error('You must be an administrator to view this page LMS.');
		}else{
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

			$courslist = $this->Common_model->insert_info("ims_training_assign",array('lms_training_id'=>$training_id,'lms_sessions_id'=>$session_id));

			$this->data['title'] = $this->lang->line('build_session_session');
			$this->data['url']=$training_id;
			
			$sessions=$this->Classroom_model->buildsession($training_id);
			$this->data['sessions'] = $sessions;
			$this->_render_page('lms_admin/training/add_session', $this->data);
		}
	}

	public function add_video_to_training_assign($training_id,$video_id){
		/*check login by role after login*/
		if (!$this->ion_auth->logged_in())
		{
			// redirect them to the login page
			redirect('auth/login', 'refresh');
		}
		else if (!$this->ion_auth->is_admin()) // remove this elseif if you want to enable this for non-admins
		{
			// redirect them to the home page because they must be an administrator to view this
			return show_error('You must be an administrator to view this page.');
		}
		else if(!$this->ion_auth->is_modules('LMS')){
			// Showing error  because they must be LMS  to view this
			return show_error('You must be an administrator to view this page LMS.');
		}else{
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

			$courslist = $this->Common_model->insert_info("ims_training_assign",array('lms_training_id'=>$training_id,'lms_video_id'=>$video_id));

			$this->data['url']=$training_id;

			$this->data['title'] = $this->lang->line('build_session_video');
			
			$videos=$this->Classroom_model->buildvideo($training_id);
			$this->data['videos'] = $videos;
			$this->_render_page('lms_admin/training/add_video', $this->data);
		}
	}

	public function add_assignment_to_training_assign($training_id,$assignment_id){
		/*check login by role after login*/
		if (!$this->ion_auth->logged_in())
		{
			// redirect them to the login page
			redirect('auth/login', 'refresh');
		}
		else if (!$this->ion_auth->is_admin()) // remove this elseif if you want to enable this for non-admins
		{
			// redirect them to the home page because they must be an administrator to view this
			return show_error('You must be an administrator to view this page.');
		}
		else if(!$this->ion_auth->is_modules('LMS')){
			// Showing error  because they must be LMS  to view this
			return show_error('You must be an administrator to view this page LMS.');
		}else{
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

			$courslist = $this->Common_model->insert_info("ims_training_assign",array('lms_training_id'=>$training_id,'lms_assignment_id'=>$assignment_id));

			$this->data['url']=$training_id;
			
			$this->data['title'] = $this->lang->line('build_session_assignment');
			
			//assignment table data
			$assignments=$this->Classroom_model->buildassignment($training_id);
			$this->data['assignments'] = $assignments;
			$this->_render_page('lms_admin/training/add_assignment', $this->data);
		}
	}

	public function add_feedback_to_training_assign($training_id,$feedback_id){
		/*check login by role after login*/
		if (!$this->ion_auth->logged_in())
		{
			// redirect them to the login page
			redirect('auth/login', 'refresh');
		}
		else if (!$this->ion_auth->is_admin()) // remove this elseif if you want to enable this for non-admins
		{
			// redirect them to the home page because they must be an administrator to view this
			return show_error('You must be an administrator to view this page.');
		}
		else if(!$this->ion_auth->is_modules('LMS')){
			// Showing error  because they must be LMS  to view this
			return show_error('You must be an administrator to view this page LMS.');
		}else{
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

			$courslist = $this->Common_model->insert_info("ims_training_assign",array('lms_training_id'=>$training_id,'lms_feedback_id'=>$feedback_id));

			$this->data['url']=$training_id;
			
			$this->data['title'] = $this->lang->line('build_session_feedback');
			
			//video table data
			$feedback=$this->Classroom_model->buildfeedback($training_id);
			$this->data['feedback'] = $feedback;
			$this->_render_page('lms_admin/training/add_feedback', $this->data);
		}
	}

	/**
	 * Create a new Video
	 */
	public function addvideo()
	{
		$userId = $this->ion_auth->get_user_id();
		if (!$this->ion_auth->logged_in())
		{
			// redirect them to the login page
			redirect('auth/login', 'refresh');
		}
		else if (!$this->ion_auth->is_admin()) // remove this elseif if you want to enable this for non-admins
		{
			// redirect them to the home page because they must be an administrator to view this
			return show_error('You must be an administrator to view this page.');
		}
		else if(!$this->ion_auth->is_modules('LMS')){
			// Showing error  because they must be LMS  to view this
			return show_error('You must be an administrator to view this page LMS.');
		}else{			
			$this->data['title'] = $this->lang->line('create_video_heading');
			
			if (isset($_POST) && !empty($_POST))
			{
				// do we have a valid request?
				if ($this->_valid_csrf_nonce() === FALSE)
				{
					show_error($this->lang->line('error_csrf'));
				}
			
				// validate form input
				$this->form_validation->set_rules('video_name', str_replace(':', '', $this->lang->line('index_videoname_th')), 'required');
				$this->form_validation->set_rules('type', str_replace(':', '', $this->lang->line('index_type_th')), 'required');
				$this->form_validation->set_rules('status', str_replace(':', '', $this->lang->line('def_status')), 'required');
			
				if ($this->form_validation->run() === TRUE)
				{
					$data_arr = array(
						'name' =>$this->input->post('video_name'),
						'description' => $this->input->post('description'),
						'type' =>$this->input->post('type'),
						'url' =>$this->input->post('url'),
						'status_id'=>$this->input->post('status'),
						'cpd_points'=>$this->input->post('cpd_points'),
						'created_at'=>date('y-m-d'),
						'created_by'=>$userId,											
					);				
					$data_arr = $this->security->xss_clean($data_arr);
					$insert_id = $this->Common_model->insert_info('lms_videos',$data_arr);
					if($insert_id){
						$this->session->set_flashdata('message', "Video added successfully.");						
						redirect('lmsadmin/elearning/videos', 'refresh');
					}	
					
					
				}
			}
				$this->data['csrf'] = $this->_get_csrf_nonce();
				$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');
				$this->data['video_name'] = array('name' => 'video_name',
					'id' => 'video_name',
					'class'=>'md-input',
					'type' => 'text',
					'value' => $this->form_validation->set_value('video_name'),
				);
				
				$this->data['description'] = array('name' => 'description',
					'id' => 'description',
					'class'=>'md-input',
					'value' => set_value('description'),
				);
				
				
				
				
				$type = array('v'=> 'Video', 'u'=> 'URL');
				$this->data['type'] = array(
					'name' => 'type',
					'id' => 'type',
					'options' => 	$type,
					'data-md-selectize'=>'',
					'selected' => set_value('type'),
				);
				
				$this->data['url'] = array('name' => 'url',
					'id' => 'url',
					'class'=>'md-input',
					'type' => 'text',
					'value' => set_value('url'),
				);
				
				$this->data['cpd_points'] = array('name' => 'cpd_points',
					'id' => 'cpd_points',
					'class'=>'md-input',
					'type' => 'text',
					'value' => set_value('cpd_points'),
				);
				
				$status = array(
						'1'         => 'Active',
						'2'           => 'In Active'						
					);
				$this->data['status'] = array(
					'name' => 'status',
					'id' => 'status',
					'options' => 	$status,
					'data-md-selectize'=>'',
					'selected' => set_value('status'),
				);
				$this->_render_page('lms_admin/videos/add', $this->data);
		}
		
		
	}
	
	/**
	 * Update user
	 */
	
	 public function updatevideo($id){
		
		if(!$this->Common_model->is_exits('lms_videos','lms_video_id',array('lms_video_id'=>$id))){
			$this->session->set_flashdata('message', "Somthing error!, Please try again");		
			redirect('lmsadmin/elearning/videos', 'refresh');
		}
		
		$this->data['title'] = $this->lang->line('edit_video_heading');
		$userId = $this->ion_auth->get_user_id();
		if (!$this->ion_auth->logged_in())
		{
			// redirect them to the login page
			redirect('auth/login', 'refresh');
		}
		else if (!$this->ion_auth->is_admin()) // remove this elseif if you want to enable this for non-admins
		{
			// redirect them to the home page because they must be an administrator to view this
			return show_error('You must be an administrator to view this page.');
		}
		else if(!$this->ion_auth->is_modules('LMS')){
			// Showing error  because they must be LMS  to view this
			return show_error('You must be an administrator to view this page LMS.');
		}else{
			$videos = $this->Common_model->select_info("lms_videos",array('lms_video_id'=>$id));
			$videos = $videos[0];
			
			
			// validate form input
				$this->form_validation->set_rules('video_name', str_replace(':', '', $this->lang->line('index_videoname_th')), 'required');
				$this->form_validation->set_rules('type', str_replace(':', '', $this->lang->line('index_type_th')), 'required');
				$this->form_validation->set_rules('status', str_replace(':', '', $this->lang->line('def_status')), 'required');
				
			if (isset($_POST) && !empty($_POST))
			{
				// do we have a valid request?
				if ($this->_valid_csrf_nonce() === FALSE || $id != $this->input->post('id'))
				{
					show_error($this->lang->line('error_csrf'));
				}
				if ($this->form_validation->run() === TRUE){
					$data_arr = array(
						'name' =>$this->input->post('video_name'),
						'description' => $this->input->post('description'),
						'type' =>$this->input->post('type'),
						'url' =>$this->input->post('url'),
						'status_id'=>$this->input->post('status'),
						'cpd_points'=>$this->input->post('cpd_points'),
						'created_at'=>date('y-m-d'),
						'created_by'=>$userId,											
					);
					
					$data_arr = $this->security->xss_clean($data_arr);
					$insert_id = $this->Common_model->update_info('lms_videos',$data_arr,array('lms_video_id'=>$id));
					if($insert_id){
						$this->session->set_flashdata('message', "Course updated successfully.");						
						redirect('lmsadmin/elearning/videos', 'refresh');
					}	
				}
			}
				$this->data['csrf'] = $this->_get_csrf_nonce();
				$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');
				$this->data['video_name'] = array('name' => 'video_name',
					'id' => 'video_name',
					'class'=>'md-input',
					'type' => 'text',
					'value' => $this->form_validation->set_value('video_name',$videos['name']),
				);
				
				$this->data['description'] = array('name' => 'description',
					'id' => 'description',
					'class'=>'md-input',
					'value' => set_value('description',$videos['description']),
				);
							
				
				$type = array('v'=> 'Video', 'u'=> 'URL');
				$this->data['type'] = array(
					'name' => 'type',
					'id' => 'type',
					'options' => 	$type,
					'data-md-selectize'=>'',
					'selected' => set_value('type',$videos['type']),
				);
				
				$this->data['url'] = array('name' => 'url',
					'id' => 'url',
					'class'=>'md-input',
					'type' => 'text',
					'value' => set_value('url',$videos['url']),
				);
				
				$this->data['cpd_points'] = array('name' => 'cpd_points',
					'id' => 'cpd_points',
					'class'=>'md-input',
					'type' => 'text',
					'value' => set_value('cpd_points',$videos['cpd_points']),
				);
				
				$status = array(
						'1'         => 'Active',
						'2'           => 'In Active'						
					);
				$this->data['status'] = array(
					'name' => 'status',
					'id' => 'status',
					'options' => 	$status,
					'data-md-selectize'=>'',
					'selected' => set_value('status',$videos['status_id']),
				);
				$this->data['lms_video_id'] = $videos['lms_video_id'];
				$this->_render_page('lms_admin/videos/add', $this->data);
		}
		
	 }	
	
	/**
	 * @return array A CSRF key-value pair
	 */
	
	
	
	/* View Assignment
	 * @ GET all List
	 * @ prama Post 
	*/
	public function assignments(){
		
		/*check login by role after login*/
		if (!$this->ion_auth->logged_in())
		{
			// redirect them to the login page
			redirect('auth/login', 'refresh');
		}
		else if (!$this->ion_auth->is_admin()) // remove this elseif if you want to enable this for non-admins
		{
			// redirect them to the home page because they must be an administrator to view this
			return show_error('You must be an administrator to view this page.');
		}
		else if(!$this->ion_auth->is_modules('LMS')){
			// Showing error  because they must be LMS  to view this
			return show_error('You must be an administrator to view this page LMS.');
		}else{
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');
			$this->data['title'] = $this->lang->line('assignments_management');
			
			$assignments = $this->Common_model->select_info("lms_assignment");
			$this->data['assignments'] = $assignments;
			$this->_render_page('lms_admin/assignment/index', $this->data);
		}
		 
	}
	
	
	
	/**
	 * Create a new Assignment
	 */
	public function addassignment()
	{
		$userId = $this->ion_auth->get_user_id();
		if (!$this->ion_auth->logged_in())
		{
			// redirect them to the login page
			redirect('auth/login', 'refresh');
		}
		else if (!$this->ion_auth->is_admin()) // remove this elseif if you want to enable this for non-admins
		{
			// redirect them to the home page because they must be an administrator to view this
			return show_error('You must be an administrator to view this page.');
		}
		else if(!$this->ion_auth->is_modules('LMS')){
			// Showing error  because they must be LMS  to view this
			return show_error('You must be an administrator to view this page LMS.');
		}else{			
			$this->data['title'] = $this->lang->line('create_assignments_heading');
			
			if (isset($_POST) && !empty($_POST))
			{
				// do we have a valid request?
				if ($this->_valid_csrf_nonce() === FALSE)
				{
					show_error($this->lang->line('error_csrf'));
				}
			
				// validate form input
				$this->form_validation->set_rules('name', str_replace(':', '', $this->lang->line('index_assign_name_th')), 'required');
				$this->form_validation->set_rules('score_max', str_replace(':', '', $this->lang->line('index_max_score')), 'required');
				$this->form_validation->set_rules('passing', str_replace(':', '', $this->lang->line('assign_passing_th')), 'required');
				$this->form_validation->set_rules('status', str_replace(':', '', $this->lang->line('index_com_stand_th')), 'required');
			
				if ($this->form_validation->run() === TRUE)
				{
					$data_arr = array(
						'name' =>$this->input->post('name'),
						'description' => $this->input->post('description'),
						'duration ' =>$this->input->post('duration '),
						'score_max' =>$this->input->post('score_max'),
						'passing'=>$this->input->post('passing'),
						'cpd_points'=>$this->input->post('cpd_points'),
						'instructions'=>$this->input->post('instructions'),
						'document'=>$this->input->post('document'),												
						'status_id'=>$this->input->post('status'),					
						'created_at'=>date('y-m-d'),
						'created_by'=>$userId,
											
					);				
					$data_arr = $this->security->xss_clean($data_arr);
					$insert_id = $this->Common_model->insert_info('lms_assignment',$data_arr);
					if($insert_id){
						$this->session->set_flashdata('message', "Assignment added successfully.");						
						redirect('lmsadmin/elearning/assignments', 'refresh');
					}	
					
					
				}
			}
				$this->data['csrf'] = $this->_get_csrf_nonce();
				$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');
				$this->data['name'] = array('name' => 'name',
					'id' => 'name',
					'class'=>'md-input',
					'type' => 'text',
					'value' => $this->form_validation->set_value('name'),
				);
				$this->data['description'] = array('name' => 'description',
					'id' => 'description',
					'class'=>'md-input',
					'value' => set_value('description'),
				);
				
				$this->data['duration'] = array('name' => 'duration',
					'id' => 'duration',
					'class'=>'uk-form-width-medium',
					'type' => 'number',
					'value' => set_value('duration'),
				);
				
				$this->data['score_max'] = array('name' => 'score_max',
					'id' => 'score_max',
					'class'=>'md-input',
					'type' => 'number',					
					'value' => set_value('score_max'),
				);
				$this->data['passing'] = array('name' => 'passing',
					'id' => 'passing',
					'class'=>'md-input',
					'type' => 'number',
					'value' => set_value('passing'),
				);
				
				$this->data['instructions'] = array('name' => 'instructions',
					'id' => 'instructions',
					'class'=>'md-input',
					'value' => set_value('instructions'),
				);
				
				$this->data['cpd_points'] = array('name' => 'cpd_points',
					'id' => 'cpd_points',
					'class'=>'md-input',
					'type' => 'text',
					'value' => set_value('cpd_points'),
				);
				
				$status = array(
						'1'         => 'Active',
						'2'           => 'In Active'						
					);
				$this->data['status'] = array(
					'name' => 'status',
					'id' => 'status',
					'options' => 	$status,
					'data-md-selectize'=>'',
					'selected' => set_value('status'),
				);
				$this->_render_page('lms_admin/assignment/add', $this->data);
		}
		
		
	}
	
	
	
	
	
	
	
	/**
	 * Edit and Update Assignment
	 */
	public function updateassignment($id)
	{
		if(!$this->Common_model->is_exits('lms_assignment','lms_assignment_id',array('lms_assignment_id'=>$id))){
			$this->session->set_flashdata('message', "Somthing error!, Please try again");		
			redirect('lmsadmin/elearning/assignments', 'refresh');
		}
		
		$userId = $this->ion_auth->get_user_id();
		if (!$this->ion_auth->logged_in())
		{
			// redirect them to the login page
			redirect('auth/login', 'refresh');
		}
		else if (!$this->ion_auth->is_admin()) // remove this elseif if you want to enable this for non-admins
		{
			// redirect them to the home page because they must be an administrator to view this
			return show_error('You must be an administrator to view this page.');
		}
		else if(!$this->ion_auth->is_modules('LMS')){
			// Showing error  because they must be LMS  to view this
			return show_error('You must be an administrator to view this page LMS.');
		}else{			
			$this->data['title'] = $this->lang->line('create_assignments_heading');
			
			if (isset($_POST) && !empty($_POST))
			{
				// do we have a valid request?
				if ($this->_valid_csrf_nonce() === FALSE)
				{
					show_error($this->lang->line('error_csrf'));
				}
			
				// validate form input
				$this->form_validation->set_rules('name', str_replace(':', '', $this->lang->line('index_assign_name_th')), 'required');
				$this->form_validation->set_rules('score_max', str_replace(':', '', $this->lang->line('index_max_score')), 'required');
				$this->form_validation->set_rules('passing', str_replace(':', '', $this->lang->line('assign_passing_th')), 'required');
				$this->form_validation->set_rules('status', str_replace(':', '', $this->lang->line('index_com_stand_th')), 'required');
			
				if ($this->form_validation->run() === TRUE)
				{
					$data_arr = array(
						'name' =>$this->input->post('name'),
						'description' => $this->input->post('description'),
						'duration ' =>$this->input->post('duration '),
						'score_max' =>$this->input->post('score_max'),
						'passing'=>$this->input->post('passing'),
						'cpd_points'=>$this->input->post('cpd_points'),
						'instructions'=>$this->input->post('instructions'),
						'document'=>$this->input->post('document'),												
						'status_id'=>$this->input->post('status'),					
						'updated_at'=>date('y-m-d'),
						'updated_by'=>$userId,
											
					);				
					$data_arr = $this->security->xss_clean($data_arr);
					$insert_id = $this->Common_model->update_info('lms_assignment',$data_arr,array('lms_assignment_id'=>$id));
					if($insert_id){
						$this->session->set_flashdata('message', "Assignment updated successfully.");						
						redirect('lmsadmin/elearning/assignments', 'refresh');
					}	
					
					
				}
			}
			$assignments = $this->Common_model->select_info("lms_assignment",array('lms_assignment_id'=>$id));
			$assignments = $assignments[0];
			
				$this->data['csrf'] = $this->_get_csrf_nonce();
				$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');
				$this->data['name'] = array('name' => 'name',
					'id' => 'name',
					'class'=>'md-input',
					'type' => 'text',
					'value' => $this->form_validation->set_value('name',$assignments['name']),
				);
				$this->data['description'] = array('name' => 'description',
					'id' => 'description',
					'class'=>'md-input',
					'value' => set_value('description',$assignments['description']),
				);
				
				$this->data['duration'] = array('name' => 'duration',
					'id' => 'duration',
					'class'=>'uk-form-width-medium',
					'type' => 'number',
					'value' => set_value('duration',$assignments['duration']),
				);
				
				$this->data['score_max'] = array('name' => 'score_max',
					'id' => 'score_max',
					'class'=>'md-input',
					'type' => 'number',					
					'value' => set_value('score_max',$assignments['score_max']),
				);
				$this->data['passing'] = array('name' => 'passing',
					'id' => 'passing',
					'class'=>'md-input',
					'type' => 'number',
					'value' => set_value('passing',$assignments['passing']),
				);
				
				$this->data['instructions'] = array('name' => 'instructions',
					'id' => 'instructions',
					'class'=>'md-input',
					'value' => set_value('instructions',$assignments['instructions']),
				);
				
				$this->data['cpd_points'] = array('name' => 'cpd_points',
					'id' => 'cpd_points',
					'class'=>'md-input',
					'type' => 'text',
					'value' => set_value('cpd_points',$assignments['cpd_points']),
				);
				
				$status = array(
						'1'         => 'Active',
						'2'           => 'In Active'						
					);
				$this->data['status'] = array(
					'name' => 'status',
					'id' => 'status',
					'options' => 	$status,
					'data-md-selectize'=>'',
					'selected' => set_value('status',$assignments['status_id']),
				);
				$this->_render_page('lms_admin/assignment/add', $this->data);
		}
		
		
	}
	
	
	public function _get_csrf_nonce()
	{		
		$this->load->helper('string');	
		$key = random_string('alnum', 8);
		$value = random_string('alnum', 20);
		$this->session->set_flashdata('csrfkey', $key);
		$this->session->set_flashdata('csrfvalue', $value);
		return array($key => $value);
	}

	/**
	 * @return bool Whether the posted CSRF token matches
	 */
	public function _valid_csrf_nonce(){
		$csrfkey = $this->input->post($this->session->flashdata('csrfkey'));
		if ($csrfkey && $csrfkey === $this->session->flashdata('csrfvalue')){
			return TRUE;
		}
			return FALSE;
	}

	/**
	 * @param string     $view
	 * @param array|null $data
	 * @param bool       $returnhtml
	 *
	 * @return mixed
	 */
	public function _render_page($view, $data = NULL, $returnhtml = FALSE)//I think this makes more sense
	{

		$this->viewdata = (empty($data)) ? $this->data : $data;

		$view_html = $this->load->view($view, $this->viewdata, $returnhtml);

		// This will return html on 3rd argument being true
		if ($returnhtml)
		{
			return $view_html;
		}
	}

}
