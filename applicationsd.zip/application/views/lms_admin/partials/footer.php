<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!--==========================
    Footer
  ============================-->
<footer id="footer">
  <div class="container">
    <div class="copyright">
    <ul>
    <li><a href="#">Home</a></li>
    
       <li><a href="#">   About CTC</a></li>
          <li><a href="#">Services</a></li>  
           <li><a href="#"> FAQ</a></li>
           
              <li><a href="#"> Contact Us</a></li>
    </ul>
    
    

    
 
    
    
   
   
      </div>
  
  </div>
</footer>
<!-- #footer --> 

<a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a> 

<!-- JavaScript Libraries --> 
<script src="<?php echo base_url('assets/website/lib/jquery/jquery.min.js');?>"></script> 
<script src="<?php echo base_url('assets/website/lib/jquery/jquery-migrate.min.js');?>"></script> 
<script src="<?php echo base_url('assets/website/lib/bootstrap/js/bootstrap.bundle.min.js');?>"></script> 
<script src="<?php echo base_url('assets/website/lib/easing/easing.min.js');?>"></script> 
<script src="<?php echo base_url('assets/website/lib/superfish/hoverIntent.js');?>"></script> 
<script src="<?php echo base_url('assets/website/lib/superfish/superfish.min.js');?>"></script> 
<script src="<?php echo base_url('assets/website/lib/wow/wow.min.js');?>"></script> 
<script src="<?php echo base_url('assets/website/lib/owlcarousel/owl.carousel.min.js');?>"></script> 
<script src="<?php echo base_url('assets/website/lib/magnific-popup/magnific-popup.min.js');?>"></script> 
<script src="<?php echo base_url('assets/website/lib/sticky/sticky.js');?>"></script> 
 
<script src="<?php echo base_url('assets/website/contactform/contactform.js');?>"></script> 
<script src="<?php echo base_url('assets/website/js/main.js');?>"></script>
<script>
$(function() {
    var Accordion = function(el, multiple) {
		this.el = el || {};
		this.multiple = multiple || false;

		// Variables privadas
		var links = this.el.find('.link');
		// Evento
		links.on('click', {el: this.el, multiple: this.multiple}, this.dropdown)
	}

	Accordion.prototype.dropdown = function(e) {
		var $el = e.data.el;
			$this = $(this),
			$next = $this.next();

		$next.slideToggle();
		$this.parent().toggleClass('open');

		if (!e.data.multiple) {
			$el.find('.submenu').not($next).slideUp().parent().removeClass('open');
		};
	}	

	var accordion = new Accordion($('#accordion'), false);
});








</script>
</body>
</html>
